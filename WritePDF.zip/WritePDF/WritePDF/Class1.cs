﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Globalization;

namespace EntegrisRPA
{
    public class WriteTextPDF: CodeActivity
    {
        [Category("Input")]
        [DisplayName("Input File")]
        [Description("Location of the input file")]
        [RequiredArgument]
        public InArgument<string> InputFile { get; set; }

        [Category("Input")]
        [DisplayName("Information")]
        [Description("Information of the text to type in pdf")]
        [RequiredArgument]
        public InArgument<string> TextToType { get; set; }

        [Category("Input")]
        [DisplayName("Output File")]
        [Description("Location of the output file")]
        [RequiredArgument]
        public InArgument<string> OutputFile { get; set; }


        protected override void Execute(CodeActivityContext context)
        {

            // Call the WriteTextOnPDF method with appropriate arguments
            string inputFile = InputFile.Get(context);
            string outputFile = OutputFile.Get(context);
            string textToType = TextToType.Get(context);
            float fontSize = 12;
            float xPosition = 100;
            float yPosition = 100;
            // Create a new PDF reader
            PdfReader reader = new PdfReader(inputFile);

            // Create a new PDF stamper
            using (PdfStamper stamper = new PdfStamper(reader, new FileStream(outputFile, FileMode.Create)))
            {
                // Create a new base font using the specified font path
                BaseFont baseFont = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

                // Iterate through each page of the PDF
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    // Get the current page
                    PdfDictionary page = reader.GetPageN(i);

                    // Create a new content byte array
                    PdfContentByte content = stamper.GetOverContent(i);

                    // Set the font and size for the text
                    content.SetFontAndSize(baseFont, fontSize);

                    // Set the position where the text will be added
                    content.SetTextMatrix(xPosition, yPosition);

                    // Show the text
                    content.ShowText(textToType);
                }
            }

        }



 

    }
}
